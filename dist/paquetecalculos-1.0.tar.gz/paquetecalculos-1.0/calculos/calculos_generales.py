def potencia(base,exponente):
    print("El resultado es ",base**exponente)

def redondear(numero):
    print("El resultado es:",round(numero))